﻿using BookStore.Model.Generated;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmMain : Form
    {
        User _user;
        BookStoreDB _db;
        public frmMain(BookStoreDB db, User user)
        {
            _user = user;
            _db = db;
            InitializeComponent();
            lblDisplayName.Text = String.Format("{0} {1}", user.FirstName, user.LastName);

        }

        public frmMain()
        {
        }

        private void tsmCategory_Click(object sender, EventArgs e)
        {
            //var categoryForm = new frmCategoryMngt(_user);
            //categoryForm.Show();
            //this.Close();
        }

        private void tsmAuthor_Click(object sender, EventArgs e)
        {
            //var authorForm = new frmAuthorMngt(_user);
            //authorForm.Show();
            //this.Close();
        }

        private void tsmBook_Click(object sender, EventArgs e)
        {
            //var bookForm = new frmBookSearch(_user);
            //bookForm.Show();
            //this.Close();
        }

        private void tsmExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var loginForm = new frmLogin();
            loginForm.Show();
            this.Close();
        }
    }
}



