﻿using BookStore.Model.Generated;
using BookStore.Services.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmCategoryDetail : Form
    {
        private readonly CategoryService _categoryService = null;
        public frmCategoryDetail(BookStoreDB db)
        {
            _categoryService = new CategoryService(db);
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var category = new Category();
            category.Title = txtTitle.Text;
            category.Description = rtbDesription.Text;
            category.CreateTime = DateTime.Now;

            _categoryService.Insert(category);
            this.Close();
        }
    }
}
