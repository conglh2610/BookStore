﻿using BookStore.Model;
using BookStore.Model.Generated;
using BookStore.Services.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmLogin : Form
    {
        BookStoreDB _db = null;
        public frmLogin()
        {
            InitializeComponent();
            _db = new BookStoreDB();
        }
        /// <summary>
        /// User clicks to access the Book Store. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLogin_Click(object sender, EventArgs e)
        {
            var userService = new UserService(_db);
            var user = userService.GetLogin(txtUserName.Text, txtPassword.Text);
            if (user != null)
            {
                var bookForm = new frmCategoyMngt(_db, user);
                bookForm.Show();
                this.Hide();
            }
        }
    }
}
