﻿using BookStore.Model.Generated;
using BookStore.Services.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmCategoyMngt : BookStore.frmMain
    {
        BookStoreDB _db = null;
        public frmCategoyMngt(BookStoreDB db, User user) : base(db, user)
        {
            _db = db;
            CategoryService caregoryService = new CategoryService(_db);
            InitializeComponent();
            var dataSource = new BindingSource();
            IEnumerable<Category> cateogoryDataSource = caregoryService.List().ToList();

            // Initialize the DataGridView.
            grvCategory.AutoGenerateColumns = false;
            grvCategory.AutoSize = true;
            grvCategory.DataSource = cateogoryDataSource;
            DataGridViewColumn colTitle = new DataGridViewTextBoxColumn();
            colTitle.DataPropertyName = "Title";
            colTitle.Name = "Title";
            grvCategory.Columns.Add(colTitle);

            DataGridViewColumn colDescription = new DataGridViewTextBoxColumn();
            colDescription.DataPropertyName = "";
            colDescription.Name = "Description";
            colDescription.DataPropertyName = "Description";
            grvCategory.Columns.Add(colDescription);

            DataGridViewImageColumn colEdit = new DataGridViewImageColumn();
            colEdit.Name = "Edit";
            colEdit.Image = new Bitmap(BookStore.Properties.Resource1.ResourceManager.GetObject("edit-24").ToString());
            colEdit.DataPropertyName = "Edit";
            grvCategory.Columns.Add(colEdit);

        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            var caregoryFrom = new frmCategoryDetail(_db);
            caregoryFrom.ShowDialog();
        }
    }
}
